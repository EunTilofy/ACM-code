#include<bits/stdc++.h>
using namespace std;
const int MN = 998244353;
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int n, m;
	cin >> n >> m;
}
